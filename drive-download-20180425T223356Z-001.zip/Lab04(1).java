import java.util.Scanner;

public class Lab04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a date in the format month/day/year:");
		Scanner keyboard = new Scanner(System.in);
		String date = keyboard.nextLine();
		String copy = date;
		
		
		//Finds the first instance of slash
		int workingIndex = copy.indexOf("/");
		//Gets everything from the start to the first slash
		String month = copy.substring(0,workingIndex);
		int months = Integer.parseInt(month);
		//Updates the input to get the next part
		copy = copy.substring(workingIndex+1);
		
		//Get the days
		workingIndex = copy.indexOf("/");
		String day = copy.substring(0,workingIndex);
		int days = Integer.parseInt(day);
		copy = copy.substring(workingIndex+1);
		
		//Get the years
		String year = copy.substring(0,workingIndex);
		int years = Integer.parseInt(year);
		copy = copy.substring(workingIndex+1);
		
		if(months <= 0 || months > 12 )
		{
			System.out.println(months + " Is not a valid month of the year!");
		}
		else
		{
			
			if(days > 31 || days < 1)
			{
				System.out.println(date + " is not a valid day!");
			}
			else
			{
				if(days < 30 && (months == 4 || months == 6 || months == 9 || months == 11))
				{
					int remainder = years % 4;
					int doubleCheck = remainder % 100;
					int tripleCheck = remainder % 400;
					if(months == 2 && (remainder == 0 || (doubleCheck == 0 && tripleCheck == 0)))
					{
						if(days == 29)
						{
							System.out.println(date + " Is a valid date!");
						}
						else
						{
							System.out.print("Something");
						}
					}else
					{
						System.out.println("Looks good to me!");
					}
				}	
				else if(months > 0 && months < 12)
				{
					System.out.println("Looks good to me!");
						
				}
				else
				{
					System.out.println(days + " Is not a valid day of that month!");
				}				
				
			}
			
		}
			
	}			

}
