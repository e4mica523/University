
public interface RPSPlayerInterface
{
	public int getPoints();
	public String getGesture();
	public void setPoints(int aPoints);
	public void setGesture(String aGesture);
	public void chooseGesture();

}
