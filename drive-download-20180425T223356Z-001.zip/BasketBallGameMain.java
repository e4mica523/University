
public class BasketBallGameMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game g = new Game();
		g.Start();
	}
}
