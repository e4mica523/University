
public interface DiamondInterface extends ShapeInterface
{
	public void setWidth(int width);
	
}
